import React, { Component } from 'react';

class About extends Component {

  render() {
    return (
      <div>
        <div class="whatIs">What is Demo ICO Blockchain Community?</div>
          <div class="textAreaWhatIs flex">
            <div>
              <div class="whatIsHeader">DEMO(ICO)</div>
              <div>duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus  duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</div>
              <div class="whatIsHeader">BEST FEATURE</div>
              <div>aakimata sanctus est Lorem ipsum dolor sit amet.ata sanctus  duo dolores et ea rebum. Stet clita kasd gubergren, no sea taki ata sanctus  duo dolores et ea rebum. Stet clita kasd gubergren, no sea taki ata sanctus  duo dolores et ea rebum. Stet clita kasd gubergren, no sea taki</div>
              <div class="whatIsHeader">METAMASK</div>
              <div>ata sanctus  duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</div>
            </div>
            <img src="https://steemitimages.com/DQmakmLJRqucg1vt9RGa6xRDDEE7mWLyorUZwC5dBKGqEik/image.png" alt="about"/>
         </div>
      </div>
    );
  }
}

export default About;
