import React, {Component} from 'react';

class Roadmap extends Component {

  render(){
    return (
      <div>
        <div class="roadmap"> Roadmap </div>
        <div class="roadmapImage">
          <img src="https://i.ibb.co/GWKhK64/white.png" alt="White Background"/>
        </div>
      </div>
    );
  }
}

export default Roadmap;
