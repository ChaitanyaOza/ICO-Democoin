import React, { Component } from 'react';

class Team extends Component {

  render() {

    return (
        <div>
          <div class="team"> Team </div>
          <div class="teamSub"> Our people are our greatest asset and biggest differentiator.</div>
          <div class="teamSub"> They also believe in having a lot of fun along the way. </div>

          <div class="teamPics">

            <div class="circlePic">
              <img src="https://www.pngitem.com/pimgs/m/146-1468479_my-profile-icon-blank-profile-picture-circle-hd.png" alt="profile"/>
              <div class="userName"> Chaitanya Oza </div>
              <div class="userText"> The CEO and bla bla, Before </div>
              <div class="userText">  Owner and  ... </div>
            </div>

            <div class="circlePic">
              <img src="https://www.pngitem.com/pimgs/m/146-1468479_my-profile-icon-blank-profile-picture-circle-hd.png" alt="profile" />
              <div class="userName"> Saumya Mutalik </div>
              <div class="userText"> The CEO and bla bla, Before </div>
              <div class="userText">  Owner and  ... </div>
            </div>

            <div class="circlePic">
              <img src="https://www.pngitem.com/pimgs/m/146-1468479_my-profile-icon-blank-profile-picture-circle-hd.png" alt="profile"/>
              <div class="userName"> Priyanshu Gandhi </div>
              <div class="userText"> The CEO and bla bla, Before </div>
              <div class="userText">  Owner and  ... </div>
            </div>
            <div class="circlePic">
              <img src="https://www.pngitem.com/pimgs/m/146-1468479_my-profile-icon-blank-profile-picture-circle-hd.png" alt="profile"/>
              <div class="userName"> Anish Awasthi </div>
              <div class="userText"> The CEO and bla bla, Before </div>
              <div class="userText">  Owner and  ... </div>
            </div>
          </div>

        </div>

    );
  }
}

export default Team;
